/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package asia.uap.dbsql;

import asia.uap.servlet.FoodLogBean;
import asia.uap.servlet.StudentBean;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

/**
 *
 * @author Kate
 */
public class Database {
    private String driver; 
    private String url; 
    private String user;
    private String pass;
    
    public Database(){
        loadSQL();
    }
    
    public void loadSQL() { //Retrieve from SQL.properties
        ResourceBundle sql = ResourceBundle.getBundle("asia.uap.dbsql.SQL");
        this.url = sql.getString("url");
        this.user = sql.getString("user");
        this.pass = sql.getString("pass"); 
        this.driver = sql.getString("driver");
    }
   
    public void loadDriver()
    {
        try{
            Class.forName(driver); 
        }catch(ClassNotFoundException err){
            err.printStackTrace();
        }
    }
    
//checks if owner exists
    public boolean isUserExist(int id) throws SQLException
    {
        loadDriver();
        Connection connect2DB = null;
        StudentBean bean = null;
        boolean verdict = false;
        
        try{
            connect2DB = DriverManager.getConnection(url, user, pass);
            String sql ="select studentID from student where studentID = ?";
            PreparedStatement ps = connect2DB.prepareStatement(sql);
            ps.setInt(1, id);
            ResultSet resultSet = ps.executeQuery();
            
            while(resultSet.next())
            {
                bean = new StudentBean();
                int n = resultSet.getInt("studentID");
                bean.setUserName(n);  //note: you cannot get "raw" data from the db
                n = bean.getUserName();
                
                if(n != 0 && n == id) //if the name retrieved exists + it's equal to the user input
                    return true;
            } 
        }catch(SQLException ex){
            ex.printStackTrace();
        }finally{
            if(connect2DB != null) 
                connect2DB.close(); 
        }
        return verdict;
    }

//checks if the password input is correct
    public boolean isPasswordCorrect(int id, String password) throws SQLException
    {
        loadDriver();
        Connection connect2DB = null;
        StudentBean bean = null;
        boolean verdict = true;
        
        try{
            connect2DB = DriverManager.getConnection(url, user, pass);
            String sql ="select passW from student where studentID = ?"; //gets the password from the specific username
            PreparedStatement ps = connect2DB.prepareStatement(sql);
            ps.setInt(1, id);
            ResultSet resultSet = ps.executeQuery();
            
            while(resultSet.next())
            {
                bean = new StudentBean();
                String pw = resultSet.getString("password");
                bean.setPassword(pw);  //note: you cannot get "raw" data from the db
                pw = bean.getPassword();
                
                if(!pw.equals(password)) //if password does not match to the given input password...
                    return false;
            } 
        }catch(SQLException ex){
            ex.printStackTrace();
        }finally{
            if(connect2DB != null) 
                connect2DB.close(); 
        }
        return verdict;
    }
    
//adds new user to the database
    public void addUser(StudentBean student) throws SQLException
    {
        loadDriver();
        Connection connect2DB = null;
        try{
            connect2DB = DriverManager.getConnection(url, user, pass);
            connect2DB.setAutoCommit(false); //turns off autosave from DB
            String sql = "insert into student(studentID, passW, yearLevel, course) values(?,?,?,?)";
            PreparedStatement ps = connect2DB.prepareStatement(sql); 
            ps.setInt(1, student.getUserName());
            ps.setString(2, student.getPassword());
            ps.setString(3, student.getYL());
            ps.setString(4, student.getCourse());
            ps.executeUpdate(); //this is for insert, delete, & update tables
            connect2DB.commit(); //starts to officially save the data into the database
        }catch(SQLException ex){
            if(connect2DB != null)
                connect2DB.rollback(); //to discard the changes and return back to the original state
            throw ex; //returns the error back to java!
        }finally{
            if(connect2DB != null) 
                connect2DB.close(); 
        }
    }
    
//adds new food log data
    public void addFoodLogData(FoodLogBean data) throws SQLException
    {
        loadDriver();
        Connection connect2DB = null;
        try{
            connect2DB = DriverManager.getConnection(url, user, pass);
            connect2DB.setAutoCommit(false); //turns off autosave from DB
            String sql = "insert into foodLog(studentID, date, image, description, notes) values(?,?,?,?,?)";
            PreparedStatement ps = connect2DB.prepareStatement(sql); 
            ps.setInt(1, data.getUserName());
            ps.setString(2, data.getDate());
            ps.setString(3, data.getImage());
            ps.setString(4, data.getDescription());
            ps.setString(5, data.getNotes());
            ps.executeUpdate(); //this is for insert, delete, & update tables
            connect2DB.commit(); //starts to officially save the data into the database
        }catch(SQLException ex){
            if(connect2DB != null)
                connect2DB.rollback(); //to discard the changes and return back to the original state
            throw ex; //returns the error back to java!
        }finally{
            if(connect2DB != null) 
                connect2DB.close(); 
        }
    }
    
//gets all food log data
    public ArrayList<FoodLogBean> getAllFoodLog() throws SQLException
    {
        loadDriver();
        Connection connect2DB = null;
        ArrayList<FoodLogBean> quesList = new ArrayList<>();
        
        try{
            connect2DB = DriverManager.getConnection(url, user, pass);
            String sql = "SELECT * FROM foodLog";
            PreparedStatement ps = connect2DB.prepareStatement(sql);
            ResultSet resultSet = ps.executeQuery(); //ps.executeQUERY() only gets the data from the db
            
            while(resultSet.next()) //moves to the next record/tuple
            {
                int id = resultSet.getInt("studentID");
                String date = resultSet.getString("date"); //column names of the database; will generate error if nonexistent
                String img = resultSet.getString("image");
                String desc = resultSet.getString("description");
                String note = resultSet.getString("notes");
                
                
                FoodLogBean data = new FoodLogBean(); 
                data.setUserName(id);
                data.setDate(date);
                data.setImage(img);
                data.setDescription(desc);
                quesList.add(data);
            }
        }catch(SQLException ex){
            ex.printStackTrace();
        }finally{
            if(connect2DB != null) 
                connect2DB.close(); 
        }
        return quesList;
    }
    
//gets the most updated food log
    public FoodLogBean getLastFoodLog() throws SQLException
    {
        loadDriver();
        Connection connect2DB = null;
        FoodLogBean data = null;
        
        try{
            connect2DB = DriverManager.getConnection(url, user, pass);
            String sql = "SELECT * FROM foodLog WHERE "
                        + "ORDER BY id DESC LIMIT 1";
            PreparedStatement ps = connect2DB.prepareStatement(sql);
            ResultSet resultSet = ps.executeQuery(); //ps.executeQUERY() only gets the data from the db
            
            while(resultSet.next()) //moves to the next record/tuple
            {
                int id = resultSet.getInt("studentID");
                String date = resultSet.getString("date"); //column names of the database; will generate error if nonexistent
                String img = resultSet.getString("image");
                String desc = resultSet.getString("description");
                String note = resultSet.getString("notes");
                
                data = new FoodLogBean(); 
                data.setUserName(id);
                data.setDate(date);
                data.setImage(img);
                data.setDescription(desc);
            }
        }catch(SQLException ex){
            ex.printStackTrace();
        }finally{
            if(connect2DB != null) 
                connect2DB.close(); 
        }
        return data;
    }
}
