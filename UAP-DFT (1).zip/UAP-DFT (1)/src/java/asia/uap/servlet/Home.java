/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package asia.uap.servlet;

import asia.uap.dbsql.Database;
import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Kate
 */
public class Home extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        //have sessions in here to get the username!!!
        
        String uri = "WEB-INF/jsp/home.jsp";
        String userName = request.getParameter("studentNo");
        int id = 0;
        String password = request.getParameter("passWord");
        boolean verdict = false;
        String emptyUserName = "";
        String emptyPassword = "";
        String errorUserName = "";
        String errorPassword = "";
        
        Database db = new Database();
        
        if(userName == null || userName.isEmpty())
        {
            emptyUserName = "No user name was inputted.";
            uri = "WEB-INF/jsp/empty.jsp";
        }
        
        else
        {
            id = Integer.parseInt(userName);
            try {
                verdict = db.isUserExist(id); //check if the userName exists
            } catch (SQLException ex) {
                Logger.getLogger(Home.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            if(!verdict)
            {
                errorUserName = "The user name inputted does not exist.";
                uri = "WEB-INF/jsp/error.jsp";
            }
        }
       
        if(password == null || password.isEmpty())
        {
            emptyPassword = "No password was inputted.";
            uri = "WEB-INF/jsp/empty.jsp";
        }
        
        else
        {
            try {
                verdict = db.isPasswordCorrect(id, password); //checks if the password is correct!
            } catch (SQLException ex) {
                Logger.getLogger(Home.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            if(!verdict)
            {
                errorPassword = "Password unmatched.";
                uri = "WEB-INF/jsp/error.jsp";
            }
        }

        if(id > 0 && password != null && !password.isEmpty())
        {
            String convertedID = Integer.toString(id);
            //using sessions that can be accessed by other files in this project
            HttpSession session = request.getSession();
            session.setAttribute("studentID", convertedID);
        }
        
        request.setAttribute("id", id);
        request.setAttribute("emptyUserName", emptyUserName);
        request.setAttribute("emptyPassword", emptyPassword);
        request.setAttribute("errorUserName", errorUserName);
        request.setAttribute("errorPassword", errorPassword);
        RequestDispatcher rd = request.getRequestDispatcher(uri); //will connect the servlet to the view/jsp
        rd.forward(request,response);
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
