/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package asia.uap.servlet;

import asia.uap.dbsql.Database;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Kate
 */
public class AddFoodLog extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        String uri = "WEB-INF/jsp/statusfoodlog.jsp";
        String date = request.getParameter("date");
        String image = request.getParameter("image");
        String description = request.getParameter("description");
        String notes = request.getParameter("notes");
        String saveSuccess = "";
        ArrayList<String> emptyFields = new ArrayList<>();
        
        if(date == null || date.isEmpty())
        {
            emptyFields.add("date");
            uri = "WEB-INF/jsp/informfoodlog.jsp";
        }
        
        if(image == null || image.isEmpty())
        {
            emptyFields.add("image");
            uri = "WEB-INF/jsp/informfoodlog.jsp";
        }
        
        if(description == null || description.isEmpty())
        {
            emptyFields.add("description");
            uri = "WEB-INF/jsp/informfoodlog.jsp";
        }
        
        if(notes == null || notes.isEmpty())
        {
            emptyFields.add("note/s");
            uri = "WEB-INF/jsp/informfoodlog.jsp";
        }
        
        if(date != null && !date.isEmpty() && image != null && !image.isEmpty() && description != null && !description.isEmpty() && notes != null && !notes.isEmpty())
        {
            Database db = new Database();
            FoodLogBean fl = new FoodLogBean();
            
            HttpSession session = request.getSession();
            String sessName = (String)(session.getAttribute("studentID"));
            int id = Integer.parseInt(sessName);
            
            fl.setUserName(id);
            fl.setDate(date);
            fl.setImage(image);
            fl.setDescription(description);
            fl.setNotes(notes);
            
            try {
                db.addFoodLogData(fl);
                
                saveSuccess = "Your inputs are now saved into our database.";
            } catch (SQLException ex) {
                Logger.getLogger(AddFoodLog.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        request.setAttribute("saveSuccess", saveSuccess);
        request.setAttribute("emptyFields", emptyFields);
        RequestDispatcher rd = request.getRequestDispatcher(uri); //will connect the servlet to the view/jsp
        rd.forward(request,response);
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
