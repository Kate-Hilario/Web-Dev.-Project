/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package asia.uap.servlet;

/**
 *
 * @author Kate
 */
public class StudentBean implements java.io.Serializable{
    private int username; //which is the student number
    private String password;
    private String yearLevel;
    private String course;
    
    public void setUserName(int id)
    {
        username = id;
    }
    
    public void setPassword(String pw)
    {
        password = pw;
    }
    
    public void setYL(String yl)
    {
        yearLevel = yl;
    }
    
    public void setCourse(String c)
    {
        course = c;
    }
    
    public int getUserName()
    {
        return this.username;
    }
    
    public String getPassword()
    {
        return this.password;
    }
    
    public String getYL()
    {
        return this.yearLevel;
    }
    
    public String getCourse()
    {
        return this.course;
    }
}
