/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package asia.uap.servlet;

/**
 *
 * @author Kate
 */
public class FoodLogBean extends StudentBean{
    private String date;
    private String image;
    private String description;
    private String notes;
    
    public void setDate(String petsa)
    {
        date = petsa;
    }
    
    public void setImage(String pic)
    {
        image = pic;
    }
    
    public void setDescription(String desc)
    {
        description = desc;
    }
    
    public void setNotes(String note)
    {
        notes = note;
    }
    
    public String getDate()
    {
        return this.date;
    }
    
    public String getImage()
    {
        return this.image;
    }
    
    public String getDescription()
    {
        return this.description;
    }
    
    public String getNotes()
    {
        return this.notes;
    }
}
