/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package asia.uap.servlet;

import asia.uap.dbsql.Database;
import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Kate
 */
public class Register extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        String uri = "WEB-INF/jsp/home.jsp";
        
        String userName = request.getParameter("studentNo");
        int id = 0;
        String password = request.getParameter("passWord");
        String yearLevel = request.getParameter("yearLevel");
        String course = request.getParameter("course");
        
        String emptyUserName = "";
        String emptyPassword = "";
        String emptyYL = "";
        String emptyCourse = "";
        String userExists = "";
        
        boolean verdict = false;
        
        Database db = new Database();
        
        if(userName == null || userName.isEmpty())
        {
            emptyUserName = "No student number was inputted.";
            uri = "WEB-INF/jsp/empty.jsp";
        }
        
        else
        {
            id = Integer.parseInt(userName);
            try {
                verdict = db.isUserExist(id); //check if the userName exists
            } catch (SQLException ex) {
                Logger.getLogger(Home.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            if(verdict)
            {
                userExists = "The user name inputted already exists in our database.";
                uri = "WEB-INF/jsp/error.jsp";
            }
        }
       
        if(password == null || password.isEmpty())
        {
            emptyPassword = "No password was inputted.";
            uri = "WEB-INF/jsp/empty.jsp";
        }
        
        if(yearLevel == null || yearLevel.isEmpty())
        {
            emptyYL = "No year level was inputted.";
            uri = "WEB-INF/jsp/empty.jsp";
        }
        
        if(course == null || course.isEmpty())
        {
            emptyCourse = "No course was inputted.";
            uri = "WEB-INF/jsp/empty.jsp";
        }
        
        if(id > 0 && password != null && !password.isEmpty() && yearLevel != null && !yearLevel.isEmpty() && course != null && !course.isEmpty())
        {
            StudentBean sb = new StudentBean();
            sb.setUserName(id);
            sb.setPassword(password);
            sb.setYL(yearLevel);
            sb.setCourse(course);
            
            try {
                db.addUser(sb); //adds the user to the database
            } catch (SQLException ex) {
                Logger.getLogger(Register.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        if(id > 0 && password != null && !password.isEmpty())
        {
            String convertedID = Integer.toString(id);
            //using sessions that can be accessed by other files in this project
            HttpSession session = request.getSession();
            session.setAttribute("studentID", convertedID);
        }
        
        request.setAttribute("id", id); //will be sent to home page jsp
        request.setAttribute("emptyUserName", emptyUserName); //the following below will be sent to empty.jsp
        request.setAttribute("emptyPassword", emptyPassword);
        request.setAttribute("emptyYL", emptyYL);
        request.setAttribute("emptyCourse", emptyCourse);
        request.setAttribute("userExists", userExists); //will be sent to error.jsp
        RequestDispatcher rd = request.getRequestDispatcher(uri); //will connect the servlet to the view/jsp
        rd.forward(request,response);
    }
    

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
